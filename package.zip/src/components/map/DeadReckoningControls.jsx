import React, { useState, useEffect } from 'react';  
import advancedDeadReckoningService from '../../services/AdvancedDeadReckoningService';  
import useIMUSensors from '../../hooks/useIMUSensors';  
import './DeadReckoningControls.css';  

const DeadReckoningControls = ({ currentLocation }) => {  
  const [isActive, setIsActive] = useState(false);  
  const [isCalibrating, setIsCalibrating] = useState(false);  
  const [stepCount, setStepCount] = useState(0);  
  const [strideLength, setStrideLength] = useState(0.75);  
  const [kalmanState, setKalmanState] = useState(null);  
  const [stepCountErrorShown, setStepCountErrorShown] = useState(false);  

  const {  
    acceleration,  
    rotationRate,  
    orientation,  
    isSupported,  
    hasPermission,  
    requestPermission,  
    checkPermissions,  
  } = useIMUSensors();  

  // افزودن لیستنر به سرویس Dead Reckoning  
  useEffect(() => {  
    const removeListener = advancedDeadReckoningService.addListener((data) => {  
      setIsActive(data.isActive);  
      setIsCalibrating(data.isCalibrating);  
      setStepCount(data.stepCount);  
      setKalmanState(data.kalmanState);  

      // نمایش خطا در صورت عدم ثبت گام  
      if (data.isActive && !data.isCalibrating && data.stepCount === 0 && !stepCountErrorShown) {  
        alert('توجه: گام برداری ثبت نمی‌شود. مطمئن شوید دستگاه حرکت دارد و سنسورها فعال هستند.');  
        setStepCountErrorShown(true);  
      }  

      // پاک کردن خطا در صورت ثبت گام  
      if (data.stepCount > 0) {  
        setStepCountErrorShown(false);  
      }  
    });  

    return () => removeListener();  
  }, [stepCountErrorShown]);  

  // ارسال داده‌های سنسورها به سرویس  
  useEffect(() => {  
    if (!isSupported || !hasPermission) {  
      console.error('سنسورهای IMU پشتیبانی نمی‌شوند یا اجازه دسترسی داده نشده است.');  
      return;  
    }  

    if (acceleration && rotationRate && orientation) {  
      advancedDeadReckoningService._processSensorData({  
        acceleration,  
        rotationRate,  
        orientation,  
      });  
    }  
  }, [acceleration, rotationRate, orientation, isSupported, hasPermission]);  

  // مدیریت تغییر طول گام  
  const handleStrideLengthChange = (e) => {  
    const newStrideLength = parseFloat(e.target.value);  
    setStrideLength(newStrideLength);  
    advancedDeadReckoningService.setStrideLength(newStrideLength);  
  };  

  // شروع/توقف ردیابی  
  const handleToggle = async () => {  
    if (!isSupported) {  
      alert('سنسورهای IMU در این دستگاه پشتیبانی نمی‌شوند.');  
      return;  
    }  

    if (!hasPermission && typeof DeviceMotionEvent.requestPermission === 'function') {  
      const permission = await requestPermission();  
      if (permission !== 'granted') {  
        alert('اجازه دسترسی به سنسورها داده نشد.');  
        return;  
      }  
    }  

    if (isActive) {  
      advancedDeadReckoningService.stop();  
    } else {  
      advancedDeadReckoningService.start();  
    }  
  };  

  // بازنشانی سیستم  
  const handleReset = () => {  
    advancedDeadReckoningService.reset();  
    setStepCount(0);  
    setKalmanState(null);  
  };  

  // خروجی لاگ  
  const handleExport = () => {  
    advancedDeadReckoningService.exportLog();  
  };  

  return (  
    <div className="dr-controls">  
      <button  
        className={`dr-button ${isActive ? 'active' : ''}`}  
        onClick={handleToggle}  
        disabled={!isSupported || (!isActive && !hasPermission && typeof DeviceMotionEvent.requestPermission === 'function')}  
      >  
        {isActive ? 'توقف ردیابی' : 'شروع ردیابی'}  
      </button>  

      <button className="dr-button" onClick={handleReset} disabled={!isActive}>  
        بازنشانی  
      </button>  

      <div className="step-counter">  
        <span>تعداد گام‌ها: {stepCount}</span>  
      </div>  

      <div className="stride-control">  
        <label>طول گام (متر): {strideLength.toFixed(2)}</label>  
        <input  
          type="range"  
          min="0.3"  
          max="1.2"  
          step="0.05"  
          value={strideLength}  
          onChange={handleStrideLengthChange}  
          disabled={!isActive}  
        />  
      </div>  
    </div>  
  );  
};  

export default DeadReckoningControls;  